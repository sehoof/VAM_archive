####################################################
####  MAPS, MAPS, MAPS!  ###########################
####################################################

setwd("/Users/rodoncas/Dropbox/LSE/VAM_maps/")
setwd("c:/Users/rodoncas/Dropbox/LSE/VAM_maps/")

# Setup instructions ------------------------------------------------------

library("sp")
library("rgdal")

#If you have any problem, follow this:
# http://www.nickeubank.com/wp-content/uploads/2015/10/RGIS1_SpatialDataTypes_part0_setup.html

# SPATIAL OBJECTS ---------------------------------------------------------

toy.coordinates <- data.frame("x" = c(1,1,1,1,1,2,3,5,6,6.5,5,6.5,8,8,8,8,8,9,10,9,10,9,10),
                              "y" = c(5,4,3,2,1,1,1,1,2,3,4,5,5,4,3,2,1,5,5,3,3,1,1))
plot(toy.coordinates)

my.first.points <- SpatialPoints(toy.coordinates)  # Convert into a spatial object
plot(my.first.points)

summary(my.first.points)

coordinates(my.first.points)

is.projected(my.first.points)  # see if a projection is defined. 

#www.spatialreference.org

crs.geo <- CRS("+init=EPSG:32633")  # UTM 33N
proj4string(my.first.points) <- crs.geo  # define projection system of our data
is.projected(my.first.points)

summary(my.first.points)

plot(my.first.points, col="red")
plot(my.first.points, col="red",cex = 5)



# Working with real vector files ------------------------------------------

library("rgeos")
library("ggplot2")
library("ggthemes")
library("readstata13")
library("dplyr")

#We want to plot the spatial distribution of spending during the 2017 General Election
cat_map <- readOGR("mapa_cat_mun", "Municipis")
glimpse(cat_map) #check dataset
summary(cat_map) #CRS?
plot(cat_map) #does it work?

#Let's try to change the CRS
CRS.new <- CRS("+proj=tmerc +lat_0=0 +lon_0=27 +k=1 +x_0=9500000 +y_0=0 +ellps=krass +units=m +no_defs ")
#http://www.spatialreference.org/ref/epsg/2643/
cat_map.new <- spTransform(cat_map, CRS.new)
plot(cat_map.new)

#Results data
df_ref <- read.dta13("data_1o.dta", nonint.factors = TRUE) 
#remove a missing
df_ref<-df_ref[!(df_ref$codi_unic==""),]

#spatial join
cat_map <- merge(cat_map, df_ref, by.x = "Codigo", by.y = "codi_unic")

# WARNING - DON'T DO THIS!
cat_map@data <- merge(cat_map@data, df_ref, by.x = "Codigo", by.y = "codi_unic")

#Let's check the data first
hist(cat_map@data$part_1o) ##Skewed
#We substitute values greater than 300 with the mean
cat_map@data$part_1o[cat_map@data$part_1o>300] <- 79.74
hist(cat_map@data$part_1o) #Looks better now

#Let's plot it
plot(cat_map, border = "red")
title(main = "Catalonia", sub = "By municipality")

#Let's complicate it a little bit more
cat_rivers <- readOGR("rivers", "rivers")
plot(cat_rivers) #Does it work? 
#Yes!

#Let's plot them together
plot(cat_map)
par(new = T)
plot(cat_rivers, col = "blue", add = T)
par(new = F)
#It does not work. WHY????

#CRS is not the same
stopifnot(proj4string(cat_map) == proj4string(cat_rivers))  # Check in same projection before combining!
summary(cat_map)
summary(cat_rivers)

MyNewProjection <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
cat_map <- spTransform(cat_map, MyNewProjection)
cat_rivers <- spTransform(cat_rivers, MyNewProjection)

#Let's try it now
plot(cat_map)
par(new = T)
plot(cat_rivers, col = "blue", add = T)
par(new = F)
#voila!

#Perhaps we are not interested in the entire region, but we only want to show a subpart of it
#How do we do it?

plot(cat_map)
axis(1);axis(2) # see where we are
plot(cat_map,xlim=c(2.5,3),ylim=c(42,42.5))

#OR if you don't know the coords, get them using locator:
plot(cat_map)
xy=locator(2,"p") # click two corners
plot(cat_map,xlim=xy$x,ylim=xy$y)

#Some of you might wonder: where is ggplot?
#We can obviously do the same with ggplot, but we need a few tricks before plotting
cat_map$id <- rownames(as.data.frame(cat_map))
cat_map.pts <- fortify(cat_map, region="id") #this only has the coordinates
cat_map.df <- merge(cat_map.pts, cat_map, by="id", type='left') # add the attributes back 

cat_rivers$id <- rownames(as.data.frame(cat_rivers))
cat_rivers.pts <- fortify(cat_rivers, region="id") #this only has the coordinates
cat_rivers.df <- merge(cat_rivers.pts, cat_rivers, by="id", type='left') # add the attributes back 


ggplot() + # the data
  geom_polygon(data=cat_map.df, aes(long,lat, group=group), 
               fill=NA, color="black",  size = 0.2) + # make polygons
  geom_path(data = cat_rivers.df, aes(x = long, y = lat, group = group), 
            color = "blue", size = 0.4) + # plot rivers
  theme(line = element_blank(),  # remove the background, tickmarks, etc
        axis.text=element_blank(),
        axis.title=element_blank(),
        panel.background = element_blank()) +
  coord_equal() 


library("sf") #New package
cat_map_sf <- st_read("mapa_cat_mun/Municipis.shp")
class(cat_map_sf)
print(cat_map_sf)
plot(cat_map_sf)

cat_map_sf <- merge(cat_map_sf, df_ref, by.x = "Codigo", by.y = "codi_unic")


plot(st_geometry(cat_map_sf)) #If we only want to plot the geometry
plot(cat_map_sf["part_1o"]) #We can't see anything
cat_map_sf$part_1o[cat_map_sf$part_1o>300] <- 79.74
plot(cat_map_sf["part_1o"]) #A bit better now
plot(cat_map_sf["part_1o"], 
     key.pos = 1, axes = TRUE, key.width = lcm(1.3), key.length = 1.0)

#We can use ggplot to deal with sf objects
ggplot() + 
  geom_sf(data = cat_map_sf,aes(fill=part_1o)) +
  scale_fill_viridis_c(option = "plasma", trans = "sqrt") 
 # coord_sf(crs = "+proj=laea +lat_0=52 +lon_0=10 +x_0=4321000 +y_0=3210000 +ellps=GRS80 +units=m +no_defs ")

#We can also incorporate the rivers
rivers_sf <- st_read("rivers/rivers.shp")
ggplot() + 
  geom_sf(data = cat_map_sf,aes(fill=part_1o)) +
  geom_sf(data = rivers_sf, col="blue") +
  scale_fill_viridis_c(option = "plasma", trans = "sqrt") 


#Remember that we do not always need to plot continuous variables
cat_map_sf %>%
  mutate(part_1o_cut = cut_interval(part_1o, 6)) %>%
  ggplot() +
  geom_sf(aes(fill = part_1o_cut))

#We can even plot a cartogram
library("cartogram")
sf_carto <- cartogram_cont(cat_map_sf, "part_1o", 3) #Create distorsions
plot(st_geometry(sf_carto), main="distorted (sf)") #Plot it

#Is this map good? 
# NO!
library("ggsn")

ggplot() + 
  geom_sf(data = cat_map_sf,aes(fill =part_1o)) +
  geom_sf(data = rivers_sf, col="blue") +
  scale_fill_continuous(low = "#fff7ec", high = "#7F0000") +
  theme(legend.title=element_blank())  +
  blank() +
  north(cat_map_sf) +
  scalebar(cat_map_sf, dist = 50, transform = FALSE, dist_unit = "km",
            model = "WGS84")

#Interactive maps
#If you want to show off or you want your date to be successfull, interactive maps are always a good option
#They can be done in several ways

library("mapview")
mapview(cat_map_sf["part_1o"]) #Pretty cool, huh?


library("tmap") #another way of doing cool interactive maps
tm_shape(cat_map) +
  tm_fill("lightgrey") +
  tm_shape(cat_map) +
  tm_polygons("part_1o", palette = "Oranges") 


tmap_mode("view")
tmap_last()
#tmap_save(map__interactive, "map_adjacent_interactive.html")

library("leaflet")
leaflet() %>% 
  addTiles() %>%
  addPolygons(data=cat_map, fillOpacity = 0.5, smoothFactor = 0.5) 

  
#Mapping is obviously not the only thing in the GIS world. 
# There are thousands of operations that can be performed. Let's see some of them.
  
#Oftentimes our data will be based on a set of latitude and longitue points 
  
library("readxl")
police_df <- read_xlsx("data_police.xlsx", sheet="data")

#We need to transform the latitude and longitude information
dms2dec <- function(dms, separators = c("º", "°", "\'", "\"")) {
  dms <- as.character(dms)
  dms <- gsub(pattern = " ", replacement = "", x = dms)
  for (s in separators) dms <- gsub(pattern = s, replacement = "_splitHere_", x = dms)
  splits <- strsplit(dms, split = "_splitHere_")
  n <- length(dms)
  deg <- min <- sec <- hem <- vector("character", n)
  for (i in 1:n) {
    deg[i] <- splits[[i]][1]
    min[i] <- splits[[i]][2]
    sec[i] <- splits[[i]][3]
    hem[i] <- splits[[i]][4]
  }
  dec <- as.numeric(deg) + (as.numeric(min) / 60) + (as.numeric(sec) / 3600)
  sign <- ifelse (hem %in% c("N", "E"), 1, -1)
  dec <- sign * dec
  return(dec)
}  


#We apply the function to the lat long
police_df$lat <- dms2dec(police_df$lat)
police_df$long <- dms2dec(police_df$long)

#We create a spatial object
police_sh <- police_df #we copy the object so we don't lose the original one
coordinates(police_sh) <- cbind(police_sh$long, police_sh$lat) #we tell R where the latitude and longnitude are
plot(police_sh) #it works!

#Let's plot everything together
plot(cat_map)
par(new = T)
plot(police_sh, col = "red", add = T)
par(new = F)
#It has worked, but remember that it is always recommended to check the CRS before we proceed

police_sh <- spTransform(police_sh, MyNewProjection) #I can't transform if I don't have a CRS!
proj4string(police_sh) <- CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")

#If for every police intervention (SOURCE) I wanted to get information about 
#its municipality (TARGET), I could run:
library("maptools")
pol.mun <- over(police_sh, cat_map)  # Get district data
pol.mun #Did it work?
police_sh <- spCbind(police_sh, pol.mun) #we recombine it so we have the target information on the source dataset


#Note that because cat_map is a SpatialPolygonDataFrame, 
#over returned the relevant row of data for each point. 
#If cat_map did not have any data, we would just get the index of the intersecting polygon 
#for each grant. We can see this behavior if we use the geometry() function to strip away the DataFrame:
over.list <- over(cat_map, geometry(police_sh), returnList = TRUE)
head(over.list)

#We are going to use this logic to know many police interventions took place by municipality
num.attacks <- sapply(over.list, length)
num.attacks <- as.data.frame(num.attacks)
cat_map@data <- cbind(cat_map@data, num.attacks)
table(cat_map@data$num.attacks)

#Let's say we want to compute a measure of exposure to police interventions based on distance

#How do we calculate centroids?
#Calculate centroids
centroids_cat <- gCentroid(cat_map, byid = TRUE)

#Did it work? Let's check it
plot(cat_map)
par(new = T)
plot(centroids_cat, col = "red", add = T)
par(new = T)
plot(police_sh, type = ".", col = "blue", add = T)
par(new = F)

#Now we want to calculate the distance between each centroid and the closest police intervention
library("geosphere")

dist <- distm(centroids_cat, police_sh)
#take the smallest value
min_Distance<-apply(dist, 1, min)
#data frame it
min_Distance <- as.data.frame(min_Distance)
#Bring the data back in
cat_map@data$Nearest_attack<-min_Distance$min_Distance

#There are other things that we can do. For instance, we can create buffers
#In order to do it, we need another projection
crs.buf <- CRS("+proj=utm +zone=30 +ellps=intl +towgs84=0.0000,0.0000,0.0000,0.000000,0.000000,0.000000,0.00000000 +units=m +no_defs" )  # UTM 33N
cat_mapb <- spTransform(cat_map, crs.buf)
police_shb <- spTransform(police_sh, crs.buf)

buffered.police.byidTRUE <- gBuffer(police_shb, width = 7000, byid = TRUE)
buffered.police.byidFALSE <- gBuffer(police_shb, width = 7000, byid = FALSE)

#let's check the differences
par(mfcol = c(1, 2))
plot(cat_mapb, main = "byid TRUE")
plot(buffered.police.byidTRUE, col = "blue", add = T)

plot(cat_mapb, main = "byid FALSE")
plot(buffered.police.byidFALSE, col = "blue", add = T)
par(mfrow=c(1,1))

#we don't want buffers to "eat" the sea
intersection_five <- gIntersection(buffered.police.byidFALSE, cat_mapb, byid = TRUE)

plot(cat_mapb)
plot(intersection_five, col = "blue", add = T)

#Area covered by each buffer
result5 <- gArea(intersection_five, byid = TRUE)

#How do we bring this information back in so we can use it? It's a bit complicated
# Convert from list to DataFrame and name result
result5 <- as.data.frame(result5)
colnames(result5) <- c("area_near_attack")
# ids are stored as row-names, so make into a column.
ids <- as.character(rownames(result5))
# Split the id into two columns based on the space in the middle.  Note the
# one place this could break is if the original names had spaces...
new.id.columns <- t(as.data.frame(strsplit(ids, " ")))
colnames(new.id.columns) <- c("id1", "id2")
# Now your results are a data.frame with separate columns for each id
# component!
result5 <- cbind(result5, new.id.columns)
head(result5)
# Move the rownames (which form the ids) into a column for merging
cat_map$id2 <- rownames(as.data.frame(cat_map))
cat_map <- merge(cat_map, result5, by = "id2", type = "left")

#There are other functions that might prove useful
cat_full <- gUnionCascaded(cat_map)
plot(cat_full)

#Remember that the sf package also allows you to do some (and new) operations
sf_cent <- st_centroid(cat_map_sf)

# plot both together to confirm that they are equivalent
ggplot() + 
  geom_sf(data = cat_map_sf, fill = 'white') +
  geom_sf(data = sf_cent, color = 'red') 


#Last thing!
#Sometimes you will be asked to run a Geographically Weighted Regression (GWR)
#Geographically  weighted  regression  (GWR)  is  an  exploratory 
#technique mainly intended to indicate where non-stationarity is taking place on the map, 
#that is where locally weighted regression coefficients move away from their global values.  

library("spgwr")
bwG <- gwr.sel(part_1o ~ Nearest_attack, data = cat_map, gweight = gwr.Gauss,
               verbose = FALSE)
gwrG <- gwr(part_1o ~ Nearest_attack, data = cat_map, bandwidth = bwG,
            gweight = gwr.Gauss, hatmatrix = TRUE)
gwrG

results<-as.data.frame(gwrG$SDF)
head(results)

#attach coefficients to original dataframe
cat_map$coefdist<-results$Nearest_attack


gwrG.dat<-gwrG$SDF
library("RColorBrewer")
cols<-brewer.pal(n=9, name="RdBu")

spplot(gwrG.dat, "localR2", main="local R^2")
spplot(gwrG.dat, "Nearest_attack", main="Nearest_attack coef")

#Moran's index
library("spdep")
# Make continuity NB (neighbors share edges)
continuity.nb <- poly2nb(cat_map, queen = FALSE)

# Plot neighbors
plot(continuity.nb, coordinates(cat_map))

# Convert to weights and summarize
continuity.listw <- nb2listw(continuity.nb, zero.policy=TRUE )
summary(continuity.listw, zero.policy=TRUE )

moran.test(cat_map$part_1o, continuity.listw, zero.policy=TRUE)

moran.plot(cat_map$part_1o, continuity.listw)


library("maptools")
result <- localmoran(cat_map$part_1o, continuity.listw, zero.policy=TRUE)
result

#Geocoding tutorial
# https://mhermans.net/post/mapping-leuvense-gangen/
