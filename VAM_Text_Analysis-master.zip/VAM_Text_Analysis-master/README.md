# Very Applied Methods - Text Analysis

Materials for a one-day course of the 'Very Applied Methods' sequence at the LSE.

These teaching materials do not exist in vacuum. There are many excellent short
and full-term courses on text analysis. We are grateful to [Pablo Barberá, Kenneth Benoit](https://lse-my459.github.io/),
[Patrick Chester, Leslie Huang and Kevin Munger](https://github.com/leslie-huang/Text-as-Data-Lab-Spr2018),
[Arthur Spirling](https://github.com/ArthurSpirling/Text-as-Data-Class-Spring-2018-) and [Will Lowe](https://github.com/conjugateprior/iqmr) for putting their
code online and allowing to be inspired by and re-use parts of their courses.
